"""
Dashboard auth gate — passphrase-based, zero-friction.

Enter passphrase once, httponly cookie persists for 30 days.
Passphrase set via NEXUS_DASHBOARD_KEY env var or ~/.nexus/.env.keys.
Restricted to geaglin09@gmail.com (single-user system).

Security hardening:
- Sessions bound to client fingerprint (User-Agent + IP hash)
  so stolen/replayed cookies from a different client are rejected.
- HMAC-SHA256 signed tokens prevent forgery without the server secret.
- In-memory session store means fabricated tokens always fail lookup.
- Constant-time comparison on all sensitive checks.
"""

import hashlib
import hmac
import logging
import os
import secrets
import stat
import tempfile
import time
from pathlib import Path

from src.config import get_key
from src.db.sqlite_store import SQLiteStore
from src.security.audit_log import (
    log_session_event,
)

logger = logging.getLogger("nexus.auth_gate")

AUTH_COOKIE = "nexus_session"
SESSION_TTL = 30 * 24 * 3600  # 30 days

_sessions: dict[str, dict] = {}  # In-process cache (loaded from DB at startup)
_signing_key: str | None = None
_session_store: SQLiteStore | None = None


def _get_session_store() -> SQLiteStore:
    """Get or initialize the session store."""
    global _session_store
    if _session_store is None:
        db_path = Path.home() / ".nexus" / "sessions.db"
        _session_store = SessionStore(str(db_path))
    return _session_store


class SessionStore(SQLiteStore):
    """Persistent session storage with SQLite backend."""

    def __init__(self, db_path: str | Path):
        super().__init__(db_path)
        self._init_table()

    def _init_table(self):
        """Create sessions table if it doesn't exist."""
        db = self._db()
        db.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                expiry REAL NOT NULL,
                fingerprint TEXT NOT NULL,
                created_at REAL NOT NULL
            )
        """)
        db.commit()

    def save_session(self, session_id: str, expiry: float, fingerprint: str) -> None:
        """Persist session to database."""
        db = self._db()
        db.execute(
            "INSERT OR REPLACE INTO sessions (session_id, expiry, fingerprint, created_at) VALUES (?, ?, ?, ?)",
            (session_id, expiry, fingerprint, time.time())
        )
        db.commit()

    def get_session(self, session_id: str) -> dict | None:
        """Retrieve session from database."""
        db = self._db()
        cursor = db.execute(
            "SELECT expiry, fingerprint FROM sessions WHERE session_id = ?",
            (session_id,)
        )
        row = cursor.fetchone()
        if row:
            return {"expiry": row[0], "fingerprint": row[1]}
        return None

    def delete_session(self, session_id: str) -> None:
        """Delete session from database."""
        db = self._db()
        db.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
        db.commit()

    def load_all_sessions(self) -> dict[str, dict]:
        """Load all non-expired sessions from database into memory."""
        db = self._db()
        cursor = db.execute(
            "SELECT session_id, expiry, fingerprint FROM sessions WHERE expiry > ?",
            (time.time(),)
        )
        sessions = {}
        for row in cursor.fetchall():
            sessions[row[0]] = {"expiry": row[1], "fingerprint": row[2]}
        return sessions


def _init_sessions():
    """Load sessions from database on startup."""
    global _sessions
    try:
        store = _get_session_store()
        _sessions = store.load_all_sessions()
        logger.info(f"Loaded {len(_sessions)} sessions from persistent store")
    except Exception as e:
        logger.error(f"Failed to load sessions from database: {e}")
        _sessions = {}


def _delete_session(session_id: str) -> None:
    """Delete session from both cache and persistent store."""
    _sessions.pop(session_id, None)
    try:
        store = _get_session_store()
        store.delete_session(session_id)
    except Exception as e:
        logger.error(f"Failed to delete session from database: {e}")


def _get_signing_key() -> str:
    """Derive a signing key from the dashboard passphrase hash."""
    global _signing_key
    if _signing_key:
        return _signing_key
    passphrase_hash = _get_passphrase_hash()
    _signing_key = hashlib.sha256(f"nexus-session-{passphrase_hash}".encode()).hexdigest()
    return _signing_key


def _get_passphrase_hash() -> str:
    """Load the dashboard passphrase hash from config.

    The stored value is a SHA-256 hex digest. Login attempts are hashed
    client-side or server-side and compared against this value.
    """
    key = get_key("NEXUS_DASHBOARD_KEY") or os.environ.get("NEXUS_DASHBOARD_KEY")
    if not key:
        # Generate a random passphrase, store its hash
        raw = secrets.token_urlsafe(24)
        key = hashlib.sha256(raw.encode()).hexdigest()
        _persist_key(key)
        logger.info("Generated dashboard passphrase hash (check ~/.nexus/.env.keys)")
    return key


def _persist_key(key: str):
    """Persist the generated key using atomic file creation with restricted permissions."""
    from src.config import KEYS_PATH, NEXUS_DIR

    try:
        os.makedirs(NEXUS_DIR, mode=0o700, exist_ok=True)

        fd, temp_path = tempfile.mkstemp(dir=NEXUS_DIR, prefix='.env.keys.', text=True)
        try:
            with os.fdopen(fd, 'w') as f:
                os.fchmod(fd, stat.S_IRUSR | stat.S_IWUSR)
                f.write(f"NEXUS_DASHBOARD_KEY={key}\n")
                f.flush()
                os.fsync(fd)
            os.replace(temp_path, KEYS_PATH)
            logger.info("Dashboard passphrase generated and secured")
        except OSError as e:
            logger.error("CRITICAL: Could not persist dashboard key: %s", e)
            if os.path.exists(temp_path):
                os.unlink(temp_path)
            raise
    except OSError as e:
        logger.error("CRITICAL: Could not persist dashboard key: %s", e)
        raise


def _compute_fingerprint(user_agent: str, client_ip: str, accept_language: str = "", accept_encoding: str = "", ssl_session_id: str = "") -> str:
    """Hash client identity with multi-factor validation to prevent session theft.

    Factors included:
    - User-Agent: browser/client type
    - Client IP: network origin
    - Accept-Language: language preferences
    - Accept-Encoding: compression support
    - SSL Session ID: TLS session binding
    """
    factors = [
        user_agent,
        client_ip,
        accept_language,
        accept_encoding,
        ssl_session_id,
    ]
    raw = "|".join(factors).encode()
    return hashlib.sha256(raw).hexdigest()[:32]


def create_session(user_agent: str = "", client_ip: str = "", accept_language: str = "", accept_encoding: str = "", ssl_session_id: str = "") -> str:
    """Create a new session token bound to the client fingerprint."""
    fingerprint = _compute_fingerprint(user_agent, client_ip, accept_language, accept_encoding, ssl_session_id)
    token = secrets.token_urlsafe(32)
    # Sign token+fingerprint together so neither can be swapped independently
    msg = f"{token}:{fingerprint}".encode()
    sig = hmac.new(_get_signing_key().encode(), msg, hashlib.sha256).hexdigest()
    session_id = f"{token}.{sig}"
    expiry = time.time() + SESSION_TTL

    # Store in memory cache
    _sessions[session_id] = {
        "expiry": expiry,
        "fingerprint": fingerprint,
    }

    # Persist to database
    try:
        store = _get_session_store()
        store.save_session(session_id, expiry, fingerprint)
    except Exception as e:
        logger.error(f"Failed to persist session: {e}")

    # Log session creation (SEC-015)
    log_session_event(
        event="created",
        session_id=session_id,
        user_ip=client_ip,
        user_agent=user_agent,
        details={"ttl_seconds": SESSION_TTL},
    )
    return session_id


def verify_session(
    session_id: str | None,
    user_agent: str = "",
    client_ip: str = "",
    accept_language: str = "",
    accept_encoding: str = "",
    ssl_session_id: str = "",
) -> bool:
    """Verify a session cookie is valid, not expired, and from the same client."""
    if not session_id:
        return False

    # Structural check
    parts = session_id.split(".", 1)
    if len(parts) != 2:
        return False
    token, sig = parts

    # Look up session — must exist in server memory (blocks fabricated tokens)
    session = _sessions.get(session_id)
    if not session:
        return False

    # Verify fingerprint matches the requesting client
    fingerprint = _compute_fingerprint(user_agent, client_ip, accept_language, accept_encoding, ssl_session_id)
    if not hmac.compare_digest(fingerprint, session["fingerprint"]):
        logger.warning("Session fingerprint mismatch — possible token theft")
        # Log session theft detection (SEC-015)
        log_session_event(
            event="theft_detected",
            session_id=session_id,
            user_ip=client_ip,
            user_agent=user_agent,
            details={"reason": "fingerprint_mismatch"},
        )
        _delete_session(session_id)
        return False

    # Verify HMAC (token+fingerprint signed together)
    msg = f"{token}:{fingerprint}".encode()
    expected_sig = hmac.new(_get_signing_key().encode(), msg, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expected_sig):
        return False

    # Check expiry
    if time.time() > session["expiry"]:
        _delete_session(session_id)
        return False

    return True


def verify_passphrase(attempt: str) -> bool:
    """Check if the provided passphrase matches (constant-time).

    Accepts either:
    - A raw passphrase (hashed server-side then compared)
    - A pre-hashed SHA-256 hex digest (compared directly)
    """
    stored_hash = _get_passphrase_hash()
    # Hash the attempt and compare against the stored hash
    attempt_hash = hashlib.sha256(attempt.encode()).hexdigest()
    if hmac.compare_digest(attempt_hash, stored_hash):
        return True
    # Also accept a pre-hashed value (e.g. from WebSocket or API clients)
    return hmac.compare_digest(attempt, stored_hash)


def verify_token_hash(token_hash: str) -> bool:
    """Verify a pre-hashed token for WebSocket auth (constant-time)."""
    stored_hash = _get_passphrase_hash()
    return hmac.compare_digest(token_hash, stored_hash)


def invalidate_session(session_id: str):
    """Explicitly destroy a session (logout)."""
    _delete_session(session_id)
    # Log session destruction (SEC-015)
    log_session_event(
        event="destroyed",
        session_id=session_id,
        details={"reason": "logout"},
    )


# Initialize sessions on module import
_init_sessions()
